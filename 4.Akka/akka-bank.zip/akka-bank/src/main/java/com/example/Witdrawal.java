package com.example;

public class Witdrawal {
    public final String text;

    public Witdrawal(String text) {
        this.text = text;
    }
}

