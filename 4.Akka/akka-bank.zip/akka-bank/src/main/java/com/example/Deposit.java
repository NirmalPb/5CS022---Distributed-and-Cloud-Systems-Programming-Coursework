package com.example;

public class Deposit {
    public final String text;

    public Deposit(String text) {
        this.text = text;
    }
}

